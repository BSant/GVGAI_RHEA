package tracks.singlePlayer.advanced.sampleRHEA_modified_RedAvoid16;
import core.game.StateObservation;
import core.player.AbstractPlayer;
import ontology.Types;
import tools.ElapsedCpuTimer;
import tracks.singlePlayer.tools.Heuristics.StateHeuristic;
import tracks.singlePlayer.tools.Heuristics.WinScoreHeuristic;

import java.util.*;

public class Agent extends AbstractPlayer {

    // variable
    private int POPULATION_SIZE = 1;
    private int SIMULATION_DEPTH = 6;
    private double DISCOUNT = 1; //0.99;
    private int CROSSOVER_TYPE = UNIFORM_CROSS;

    // set
    private boolean REEVALUATE = false;
  //  private boolean REPLACE = false;
    private int MUTATION = 1;
    private int TOURNAMENT_SIZE = 2;
    private int NO_PARENTS = 2;
    private int RESAMPLE = 1;
    private int ELITISM = 1;
    private int FMCALLS = 0;
    private int MAXCALLS = 900;
    private int REROLLPROB = 100;
    
    // constants
    private final long BREAK_MS = 10;
    public static final double epsilon = 1e-6;
    static final int POINT1_CROSS = 0;
    static final int UNIFORM_CROSS = 1;

    private Individual[] population, nextPop;
    private int NUM_INDIVIDUALS = 0;
    public static int N_ACTIONS;
    public static HashMap<Integer, Types.ACTIONS> action_mapping;
    public static int ID = 0;

    private ElapsedCpuTimer timer;
    public static Random randomGenerator;

    private StateHeuristic heuristic;
    private double acumTimeTakenEval = 0,avgTimeTakenEval = 0, avgTimeTaken = 0, acumTimeTaken = 0;
    private int numEvals = 0, numIters = 0;
    private boolean keepIterating = true;
    private long remaining;

    /**
     * Public constructor with state observation and time due.
     *
     * @param stateObs     state observation of the current game.
     * @param elapsedTimer Timer for the controller creation.
     */
    public Agent(StateObservation stateObs, ElapsedCpuTimer elapsedTimer) {
        randomGenerator = new Random();
        heuristic = new WinScoreHeuristic(stateObs);
        this.timer = elapsedTimer;
        population = new Individual[POPULATION_SIZE];
    }

    @Override
    public Types.ACTIONS act(StateObservation stateObs, ElapsedCpuTimer elapsedTimer) {
        this.timer = elapsedTimer;
        avgTimeTaken = 0;
        acumTimeTaken = 0;
        numEvals = 0;
        acumTimeTakenEval = 0;
        numIters = 0;
        remaining = timer.remainingTimeMillis();
        //NUM_INDIVIDUALS = 0;
        keepIterating = true;
        FMCALLS = 0;

        // INITIALISE POPULATION
        init_pop(stateObs);
        //System.out.println("Population: ");
        //printPopulation();
        
        // RUN EVOLUTION
        remaining = timer.remainingTimeMillis();
        while (remaining > avgTimeTaken && remaining > BREAK_MS && keepIterating && FMCALLS<=MAXCALLS) {
            runIteration(stateObs);
            remaining = timer.remainingTimeMillis();
        }
        //System.out.println("After Evolution: ");
        //printPopulation();

        // RETURN ACTION
        Types.ACTIONS best = get_best_action(population);
        return best;
    }

    /**
     * Run evolutionary process for one generation
     * @param stateObs - current game state
     */
    private void runIteration(StateObservation stateObs) {
        ElapsedCpuTimer elapsedTimerIteration = new ElapsedCpuTimer();

        if (REEVALUATE) {
            for (int i = 0; i < ELITISM; i++) {
                if (remaining > 2*avgTimeTakenEval && remaining > BREAK_MS) { // if enough time to evaluate one more individual
                    evaluate(population[i], heuristic, stateObs);
                } else {keepIterating = false;}
            }
        }

        if (NUM_INDIVIDUALS > 1) {
            for (int i = 1; i < NUM_INDIVIDUALS; i++) {
                if (remaining > 2*avgTimeTakenEval && remaining > BREAK_MS) { // if enough time to evaluate one more individual
                    Individual newind;

                    newind = crossover();
                    newind = newind.mutate(MUTATION);

                    // evaluate new individual, insert into population
                    add_individual(newind, nextPop, i, stateObs);

                    remaining = timer.remainingTimeMillis();

                } else {keepIterating = false; break;}
            }
            Arrays.sort(nextPop, new Comparator<Individual>() {
                @Override
                public int compare(Individual o1, Individual o2) {
                    if (o1 == null && o2 == null) {
                        return 0;
                    }
                    if (o1 == null) {
                        return 1;
                    }
                    if (o2 == null) {
                        return -1;
                    }
                    return o1.compareTo(o2);
                }
            });
        } else if (NUM_INDIVIDUALS == 1){
            Individual newind = new Individual(SIMULATION_DEPTH, N_ACTIONS, randomGenerator, REROLLPROB).mutate(MUTATION);
            evaluate(newind, heuristic, stateObs);
            if (newind.value > population[0].value)
                nextPop[0] = newind;
        }

        population = nextPop.clone();

        numIters++;
        acumTimeTaken += (elapsedTimerIteration.elapsedMillis());
        avgTimeTaken = acumTimeTaken / numIters;
    }

    /**
     * Evaluates an individual by rolling the current state with the actions in the individual
     * and returning the value of the resulting state; random action chosen for the opponent
     * @param individual - individual to be valued
     * @param heuristic - heuristic to be used for state evaluation
     * @param state - current state, root of rollouts
     * @return - value of last state reached
     */
    private double evaluate(Individual individual, StateHeuristic heuristic, StateObservation state) {

        ElapsedCpuTimer elapsedTimerIterationEval = new ElapsedCpuTimer();

        StateObservation st = state.copy();
        int i;
        double acum = 0, avg;
        for (i = 0; i < SIMULATION_DEPTH; i++) {
            if (! st.isGameOver() || FMCALLS <= MAXCALLS) {
                ElapsedCpuTimer elapsedTimerIteration = new ElapsedCpuTimer();
                FMCALLS++;
                st.advance(action_mapping.get(individual.actions[i]));
                acum += elapsedTimerIteration.elapsedMillis();
                avg = acum / (i+1);
                remaining = timer.remainingTimeMillis();
                if (remaining < 2*avg || remaining < BREAK_MS) break;
            } else {
                break;
            }
        }

        StateObservation first = st.copy();
        double value = heuristic.evaluateState(first);

        // Apply discount factor
        value *= Math.pow(DISCOUNT,i);

        individual.value = value;

        numEvals++;
        acumTimeTakenEval += (elapsedTimerIterationEval.elapsedMillis());
        avgTimeTakenEval = acumTimeTakenEval / numEvals;
        remaining = timer.remainingTimeMillis();

        return value;
    }

    /**
     * @return - the individual resulting from crossover applied to the specified population
     */
    private Individual crossover() {
        Individual newind = null;
        if (NUM_INDIVIDUALS == NO_PARENTS){
            newind = new Individual(SIMULATION_DEPTH, N_ACTIONS, randomGenerator, REROLLPROB);
            Individual[] parents = new Individual[NO_PARENTS];

            ArrayList<Individual> list = new ArrayList<>();
            list.addAll(Arrays.asList(population));      	
            for(int i=0;i<NO_PARENTS;i++)
            	parents[i] = list.get(i);
            
            newind.crossover(parents, CROSSOVER_TYPE, REROLLPROB);
        }else if (NUM_INDIVIDUALS > 1) {
            newind = new Individual(SIMULATION_DEPTH, N_ACTIONS, randomGenerator, REROLLPROB);
            Individual[] tournament = new Individual[TOURNAMENT_SIZE];
            Individual[] parents = new Individual[NO_PARENTS];

            ArrayList<Individual> list = new ArrayList<>();
//            if (NUM_INDIVIDUALS > TOURNAMENT_SIZE) {
//                list.addAll(Arrays.asList(population).subList(ELITISM, NUM_INDIVIDUALS));
//            } else {
                list.addAll(Arrays.asList(population));
//            }

            //Select a number of random distinct individuals for tournament and sort them based on value
            for (int i = 0; i < TOURNAMENT_SIZE; i++) {
                int index = randomGenerator.nextInt(list.size());
                tournament[i] = list.get(index);
                list.remove(index);
            }
            Arrays.sort(tournament);

            //get best individuals in tournament as parents
            if (NO_PARENTS <= TOURNAMENT_SIZE) {
                for (int i = 0; i < NO_PARENTS; i++) {
                    parents[i] = tournament[i];
                }
                newind.crossover(parents, CROSSOVER_TYPE, REROLLPROB);
            } else {
                System.out.println("WARNING: Number of parents must be LESS than tournament size.");
            }
        }
        return newind;
    }

    /**
     * Insert a new individual into the population at the specified position by replacing the old one.
     * @param newind - individual to be inserted into population
     * @param pop - population
     * @param idx - position where individual should be inserted
     * @param stateObs - current game state
     */
    private void add_individual(Individual newind, Individual[] pop, int idx, StateObservation stateObs) {
        evaluate(newind, heuristic, stateObs);
        pop[idx] = newind.copy();
    }

    /**
     * Initialize population
     * @param stateObs - current game state
     */
    private void init_pop(StateObservation stateObs) {

        double remaining = timer.remainingTimeMillis();

        N_ACTIONS = stateObs.getAvailableActions().size() + 1;
        action_mapping = new HashMap<>();
        int k = 0;
        for (Types.ACTIONS action : stateObs.getAvailableActions()) {
            action_mapping.put(k, action);
            k++;
        }
        action_mapping.put(k, Types.ACTIONS.ACTION_NIL);
        
        /*Individual[] backup = null;
        if(population != null)
            backup = population.clone();*/

        //population = new Individual[POPULATION_SIZE];
        nextPop = new Individual[POPULATION_SIZE];
        
        int index;
        
        if(NUM_INDIVIDUALS == 0)
            index = 0;
        else { 
            if(NUM_INDIVIDUALS < ELITISM){
                index = NUM_INDIVIDUALS;
            }else{
                index = ELITISM;
                NUM_INDIVIDUALS = ELITISM;
            }
        }
        
        for(int i = 0; i < index; i++){
            population[i].advance();
            evaluate(population[i], heuristic, stateObs);
        }
        
        //System.out.println("\nIndex: "+index);

        for (int i = index; i < POPULATION_SIZE; i++) {
            if (i == index || remaining > avgTimeTakenEval && remaining > BREAK_MS) {
                population[i] = new Individual(SIMULATION_DEPTH, N_ACTIONS, randomGenerator, REROLLPROB);
                evaluate(population[i], heuristic, stateObs);
                remaining = timer.remainingTimeMillis();
                NUM_INDIVIDUALS = i+1;
            } else {break;}
        }
        
        /*if(backup != null){
            for(int i = 0; i < ELITISM; i++){
                if(i >= NUM_INDIVIDUALS)
                    break;
                population[i] = backup[i];
            }
        }*/

        if (NUM_INDIVIDUALS > 1)
            Arrays.sort(population, new Comparator<Individual>() {
                @Override
                public int compare(Individual o1, Individual o2) {
                    if (o1 == null && o2 == null) {
                        return 0;
                    }
                    if (o1 == null) {
                        return 1;
                    }
                    if (o2 == null) {
                        return -1;
                    }
                    return o1.compareTo(o2);
                }});
        for (int i = 0; i < NUM_INDIVIDUALS; i++) {
            if (population[i] != null)
                nextPop[i] = population[i].copy();
        }

    }

    /**
     * @param pop - last population obtained after evolution
     * @return - first action of best individual in the population (found at index 0)
     */
    private Types.ACTIONS get_best_action(Individual[] pop) {
        int bestAction = pop[0].actions[0];
        if (bestAction == -1)  bestAction = randomGenerator.nextInt(N_ACTIONS);
        return action_mapping.get(bestAction);
    }
    
    public static String printAction(Types.ACTIONS action){
        String character = "";
        if(null != action)
            switch (action) {
            case ACTION_UP:
                character = "↑";
                break;
            case ACTION_DOWN:
                character = "↓";
                break;
            case ACTION_LEFT:
                character = "←";
                break;
            case ACTION_RIGHT:
                character = "→";
                break;
            case ACTION_USE:
                character = "U";
                break;
            case ACTION_NIL:
                character = "N";
                break;
            default:
                break;
        }
        return character;
    }
    
    public void printPopulation(){
        System.out.println("population:");
        for(int i = 0; i < NUM_INDIVIDUALS; i++){
            System.out.println(population[i].id);
            System.out.println(population[i]);
        }
        
//        System.out.println("NextPop:");
//        for(int i = 0; i < NUM_INDIVIDUALS; i++){
//            System.out.println(nextPop[i].id);
//            System.out.println(nextPop[i]);
//        }
    }
    
    public void orderPop(){
        
        for(int i = 0; i < NUM_INDIVIDUALS-1; i++){
            for(int j = i+1; j < NUM_INDIVIDUALS-1; j++){
                if(population[i].value < population[j].value){
                    Individual ind_i = population[i];
                    population[i] = population[j];
                    population[j] = ind_i;
                }
            }
        }
    }

}
